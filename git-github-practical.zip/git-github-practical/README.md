# Git and GitHub Practical

This repository demonstrates basic Git and GitHub version control.

## Files

- `hello.c` - Simple C program
- `.gitignore` - Common files ignored by Git

## Basic Git Commands

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```
